﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shooter : MonoBehaviour {

    public GameObject shootPos;
    public float force = 1000;
    public float moveSpeed = 100f;
    public Rigidbody ballPrefab;
  

	
	// Update is called once per frame
	void Update () {

        if (Input.GetButton("Fire1"))
        {
            Rigidbody ball = Instantiate(ballPrefab, shootPos.transform.position, Quaternion.identity) as Rigidbody;
            ball.AddForce(force * shootPos.transform.forward);
        }
        float h = Input.GetAxis("Horizontal") * moveSpeed * Time.deltaTime;
        float v = Input.GetAxis("Vertical") * moveSpeed * Time.deltaTime;

        transform.Translate(h, v, 0f);
	}
}
