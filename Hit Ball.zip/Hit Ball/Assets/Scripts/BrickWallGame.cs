﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BrickWallGame : MonoBehaviour {

    public GameObject brick;
    private int columnNum = 10;//列数
    private int rowNum = 5;//行数

	// Use this for initialization
	void Start () {
        //Instantiate(brick);
        //Instantiate(brick, new Vector3(0, 5f, 0),Quaternion.identity);
        for (int rowumnIndex = 0; rowumnIndex < rowNum; rowumnIndex++){
                for (int columnIndex = 0;columnIndex < columnNum ;columnIndex ++ )
        {
            Instantiate(brick, new Vector3(columnIndex-4f, 0.5f+rowumnIndex, 0), Quaternion.identity);
            
        }
            }
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
